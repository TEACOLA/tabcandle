# tabCandle - Chrome タブ自動クローズ拡張機能

[![Chrome Web Store](https://img.shields.io/badge/Chrome_Web_Store-tabCandle-orange?logo=googlechrome)](https://chromewebstore.google.com/detail/tabcandle/eghieefcaocdlamkpefmemmbepdgkdac)
[![GitHub Pages](https://img.shields.io/badge/Privacy_Policy-GitHub_Pages-blue)](https://teacola.github.io/tabcandle/)

> 🛒 **Chrome ウェブストア公式ページ**: [https://chromewebstore.google.com/detail/tabcandle/eghieefcaocdlamkpefmemmbepdgkdac](https://chromewebstore.google.com/detail/tabcandle/eghieefcaocdlamkpefmemmbepdgkdac)

固定（ピン留め）されていない開きっぱなしのタブを、**240分（4時間）経過後にバックグラウンドで静かに自動クローズ**する軽量なChrome拡張機能（Manifest V3対応）です。

---

## 主な機能

### 1. ⏰ 未固定タブの自動クローズ（メモリ＆画面の自動整理）
- 「調べ物などでタブを開きすぎてブラウザが重くなる」を防ぐため、**固定（Pinned）されていないタブを開いてから240分（4時間）経過後に自動終了**します。
- **安心の2大保護ガード**:
  1. 📌 **固定タブ（Pinned Tabs）の完全保護**: ピン留めされた固定タブは絶対に終了しません。残したいタブは右クリックして「タブを固定」すれば安全に保護されます。
  2. 🔊 **音声再生中（動画・音楽・通話）タブの保護**: YouTubeやSpotify、Google Meet等の音声・動画再生中のタブは再生停止まで自動終了しません。
- **既存タブの個別タイマー維持**: すべてのタブが個別の正確な終了予定時間を保持して独立して動作します。

### 2. 🕯 カウントダウンに特化したミニマルUI
- **ポップアップ画面**: 開いているタブとクローズまでの残り時間を蝋燭アイコン（🕯）付きで一覧表示。
- **タブジャンプ**: リスト内のタブをクリックするだけで、そのタブへ瞬時に切り替えられます。
- 🎨 **Webセーフカラー対応（3色パレット）**: 全配色を「黒」「グレー」「オレンジ」のWebセーフカラー（216色）で統一。漆黒の背景にキャンドルの温かなオレンジの灯りが際立つ、シックで洗練されたデザインです。

---

## インストール手順（Chromeへの読み込み・更新）

### すでに読み込み済みの場合（最新版へのアップデート）
1. Chromeで `chrome://extensions` を開きます。
2. 「tabCandle」カードの右下にある **更新アイコン（ぐるぐる回る矢印）** をクリックするだけで最新版（v2.3.1）が反映されます。

### 初めてインストールする場合
1. Chromeで `chrome://extensions` を開きます。
2. 右上の **「デベロッパーモード」** をONにします。
3. 左上の **「パッケージ化されていない拡張機能を読み込む」** を押し、本フォルダ（`tabcandle`）を選択します。
4. ツールバーのパズルピースアイコンからピン留めします。

---

## ファイル構成

```
tabcandle/
├── manifest.json         # Chrome拡張機能の設定ファイル (Manifest V3, alarms/storage/tabs)
├── background.js         # バックグラウンドService Worker（自動クローズ・アラーム管理）
├── icons/                # 蝋燭アイコン画像 (16px, 32px, 48px, 128px, SVG)
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   ├── icon128.png
│   └── candle.svg
├── popup/
│   ├── popup.html        # ポップアップ画面のUI構造
│   ├── popup.css         # スタイリング（Webセーフカラー・レスポンシブトークン）
│   └── popup.js          # カウントダウン表示・タブジャンプ
└── README.md             # 本ドキュメント
```

---

## セキュリティ・プライバシー

- **完全ローカル動作**: 外部サーバーへの通信、トラッキング、データ収集は一切行いません。
- **必要最小限の権限（tabGroups権限不要）**:
  - `tabs`: タブの開設時刻管理・クローズ処理
  - `storage`: タイマー情報のローカル保存
  - `alarms`: バックグラウンドでの定期タブ生存チェック
